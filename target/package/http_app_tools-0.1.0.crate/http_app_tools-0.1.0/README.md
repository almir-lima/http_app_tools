# http_app_tools
Simple Rust lib to decode and decode Http Protocol, to my use especific

It is a experimental crate, is a my first code write in Rust.

Is a bad code and can contain many mistake, i not recomend use it.
